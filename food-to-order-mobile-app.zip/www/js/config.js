var krms_config ={				
	'ApiUrl':"https://foodtoorder.co.uk/mobileapp/api",				
	'DialogDefaultTitle':"KMRS",
	'APIHasKey':"db935c23ccc8dd861a7c0k2ca18fj8d9",
	'debug': false
};